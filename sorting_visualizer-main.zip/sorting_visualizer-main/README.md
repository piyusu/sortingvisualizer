# sorting_visualizer help understanding user the process of different sorting algoritms.
Uses bar graph to show the sorting process.
Further a user can manually set up the size of the array and speed of the sorting.
Basic sorting algorithms are used.
Majorly uses java script.
